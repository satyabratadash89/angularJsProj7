angular.module('myApp',[])
    .directive('myDirective', function(){
        return{
            restrict: 'E',
            replace: true,
            templateUrl: 'myDirective.html',
            controller:'directiveController',
            controllerAs:'directiveCtrl'
        };
    }).controller('myController',function(){

    }).controller('directiveController', function(){

    });
