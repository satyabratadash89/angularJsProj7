angular.module('myApp',[])
    .controller('firstController', function($scope){

        $scope.increment=function(){
          $scope.num++;
        };

        $scope.myBoolean = true;

        $scope.myInput = 'initial value';

        $scope.changeBoolean = function() {
            $scope.myBoolean = !$scope.myBoolean;
        };

        $scope.colors = ['Red','Green','Blue','Purple', 'Yellow'];
    })
    .controller('secondController', function($scope){

    });
