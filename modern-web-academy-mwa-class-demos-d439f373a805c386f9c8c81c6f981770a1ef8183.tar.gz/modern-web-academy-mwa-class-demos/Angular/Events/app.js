angular.module('myApp',[])
    .controller('parentController', function($scope){

        //Button to Broadcast message
        $scope.broadcastButton = function(){
            $scope.$broadcast('broadcasting-event', {message:$scope.parentInput});
        };

        // Handle emmited signals
        $scope.$on('emitting-event', function(event, args){
            $scope.emitMessage = args.message;
        });

    })
    .controller('childController', function($scope){

        // Button to emit message
        $scope.emitButton = function(){
            $scope.$emit('emitting-event', {message: $scope.childInput});
        };

        //Handled Broadcast signals
        $scope.$on('broadcasting-event', function(event, args){
            $scope.broadcastMessage = args.message;
        });

    });