angular.module('myApp',['ngResource'])
    .controller('myController', function($scope, $http, $q, $resource){

        // --- Only HTTP Request
        $scope.getRequestOne=function(){
            // This is loading the file in the data folder. For an external url,
            // it is the same thing
            $http.get('sample.json').success(function(data){
                $scope.getResponseOne = data;
            }).error(function(data){
                $scope.getResponseOne = ('Oops! Houston we have a problem!!!');
            });
        };

        $scope.postRequestOne=function(){ // Note this always fails, because of the url
            $http.post('/someUrl',{data:'Adding Data'}).success(function(data){
                // On success, add functionality
            }).error(function(data){
               $scope.postResponseOne = 'Looks like we failed again. We dont have an api for posts in this demo';
            });
        };


        // ---- HTTP and Q Request
        var getHelper = function(){
            var deferred = $q.defer();
            $http.get('sample.json')
                .success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        };
        $scope.getRequestTwo=function(){
            getHelper().then(function(data){
                $scope.getResponseTwo = data;
            },
                function(){
                    $scope.getResponseTwo = 'Looks like the promise encountered an error';
                },
                function(){
                    console.log('Hey look, the promise is sending notifications. Could be useful for keeping progress');
                });
        };

        var postHelper = function(){
            var deferred = $q.defer();
            $http.post('/someUrl', {message:'Some data'})
                .success(function (data) {
                    deferred.resolve(data);
                }).error(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        };
        $scope.postRequestTwo=function(){ // Note this will always fail
            postHelper().then(function(data){
                    //something on success
                },
                function(){
                    $scope.postResponseTwo = 'Looks like the promise encountered an error, since we are not calling an actual api for posting';
                },
                function(){
                    console.log('Hey look, the promise is sending notifications. Could be useful for keeping progress');
                });
        };


        // ---- Resource requests

        // The :id says it is an optional parameter. This we can use based on what the api requires to put, delete, even update a specific item
        var sampleResource = $resource('sample.json/:id');
        $scope.getRequestThree = function(){
            $scope.getResponseThree = sampleResource.get();// simple get request
        };

    });