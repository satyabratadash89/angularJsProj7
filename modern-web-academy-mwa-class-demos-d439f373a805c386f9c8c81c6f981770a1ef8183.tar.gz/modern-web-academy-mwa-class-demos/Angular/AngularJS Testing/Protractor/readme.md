#This angular demo goes over using protractor for testing
### This demo tests the protractor api website and its search feature

##Setup
Navigate to the Protractor testing folder

Install protractor:       npm install -g protractor <br />
Update WebDriver Manager: webdriver-manager update <br />
Start WebDriver Manager:  webdriver-manager start <br />

These commands will install protractor packages. <br />
There are two files included with demo : conf.js file and spec.js file <br />
- The conf.js file is used to configure the protractor testing component. This is where
  the seleniumAddress can be pointed to display the results of the test cases. It can
  also be used to configure which spec.js files to run <br />
- The spec.js file is where the test cases are described and implemented <br />

##Running
Navigate to the location containing the conf.js folder.
Run 'protractor conf.js' to run the tests
