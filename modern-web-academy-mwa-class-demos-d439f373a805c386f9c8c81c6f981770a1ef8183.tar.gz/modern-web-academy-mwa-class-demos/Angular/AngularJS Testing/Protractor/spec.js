// spec.js
describe('Protractor Testing Demo', function() {
  beforeEach(function() {
    browser.get('http://angular.github.io/protractor/#/api');
  });

  it('Should have a title', function() {
    expect(browser.getTitle()).toEqual('Protractor - end to end testing for AngularJS');
  });
  it('Search Something', function() {
    //Type in Angular in the search box
     var search = 'getWebElement';
     element(by.model('searchTerm')).sendKeys(search);
     browser.actions().sendKeys(protractor.Key.ENTER).perform();
     browser.waitForAngular();

     // Check if the search results contains the search term
     
     var list = element.all(by.css('.list-unstyled li'));
     expect(list.count()).toBe(1);

     expect(list.get(0).getText()).toBe(search);
  });

});
