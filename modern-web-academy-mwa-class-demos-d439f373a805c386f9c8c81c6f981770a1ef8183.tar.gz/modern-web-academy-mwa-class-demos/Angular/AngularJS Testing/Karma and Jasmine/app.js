angular.module('myApp', [])
	.controller('myController', function($scope) {

        $scope.num1 = 0;
        $scope.num2 = 0


        $scope.addButton = function(){
           $scope.addResult =  $scope.num1 + $scope.num2 +4 ;
        };

        $scope.multiplyButton = function() {
            $scope.multiplyResult =  $scope.num1 * $scope.num2;
        };

    });
