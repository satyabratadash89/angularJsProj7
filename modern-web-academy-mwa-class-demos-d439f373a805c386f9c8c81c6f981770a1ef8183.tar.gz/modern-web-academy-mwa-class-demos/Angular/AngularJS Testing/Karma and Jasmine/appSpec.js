describe('My-App testing suite', function() {

	beforeEach(module('myApp'));

	var myController;
	var $scope;

	beforeEach(inject(function($controller, $rootScope) {
		$scope = $rootScope.$new();

		myController = $controller('myController as ctrl', {
			$scope: $scope
		});
	}));

	it('Scope should be defined', function() {
		expect(!!$scope).toBe(true);
	});

	it('Add function should work', function() {
		$scope.num1 = 12;
		$scope.num2 = 3;

		$scope.addButton();

		expect($scope.addResult).toBe(12+3);
	});

	it('Multiply function should work', function() {
		$scope.num1 = 2;
		$scope.num2 = 6;

		$scope.multiplyButton();

		expect($scope.multiplyResult).toBe(2*6);
	});
});
