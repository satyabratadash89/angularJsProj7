angular.module('myApp', [])
    .controller('myController', function($scope, myFactory, myProvider, myService){
      // Controller data associated with Factory
        $scope.factoryData = {};
        $scope.callFactory = function(){
            myFactory.getData().then(function(data){
                    $scope.factoryData = data;
            });
        };

        // Controller data associated with Provider
        $scope.providerData = {};
        $scope.callProvider = function(){
            myProvider.getData()
                .then(function(data){
                    $scope.providerData = data;
                });
        };
        $scope.providerDataSetInConfig = myProvider.getProviderConfiguredData;

        // Controller data associated with Service
        $scope.serviceData = {};
        $scope.callService = function(){
            myService.getData().then(function(data){
                $scope.serviceData = data;
            });
        };


    })
    .service('myService', function($http, $q){

        this.getData = function(){
            var deferred = $q.defer();
            $http({
                method: 'JSONP',
                url: 'https://itunes.apple.com/search?term='+'Bruno Mars'+'&callback=JSON_CALLBACK'
            }).success(function(data){
                deferred.resolve(data);
            }).error(function(){
                deferred.reject('There was an error')
            });
            return deferred.promise;
        };

    })
    .factory('myFactory', function($http, $q){
        var service = {};

        service.getData = function(){
            var deferred = $q.defer();
            $http({
                method: 'JSONP',
                url: 'https://itunes.apple.com/search?term='+'Bruno Mars'+'&callback=JSON_CALLBACK'
            }).success(function(data){
                deferred.resolve(data);
            }).error(function(){
                deferred.reject('There was an error')
            });
            return deferred.promise;
        };
        return service;

    })
    .provider('myProvider', function(){
        //Going to set the artist name on the config function below
        this.providerConfigData = '';

        this.$get = function($http, $q){
            return {
                getData: function(){
                    var deferred = $q.defer();
                    $http({
                        method: 'JSONP',
                        url: 'https://itunes.apple.com/search?term='+'Bruno Mars'+'&callback=JSON_CALLBACK'
                    }).success(function(data){
                        deferred.resolve(data);
                    }).error(function(){
                        deferred.reject('There was an error')
                    });
                    return deferred.promise;
                },
                getProviderConfiguredData: this.providerConfigData
            }
        }
    }).config(function(myProviderProvider){
        //Providers are the only service you can pass into app.config
        myProviderProvider.providerConfigData = 'Bruno Mars';
    });