angular.module('myApp',['ui.router'])
    .config(function($urlRouterProvider, $stateProvider){
        $urlRouterProvider.otherwise('/home');

        $stateProvider
            .state('home', {
                url: '/home',
                templateUrl: 'home.html'
            })

            //Nested views
            .state('home.list',{
                url:'/list',
                template:'<ul><li ng-repeat="item in items">{{item}}</li></ul>',
                controller: function($scope){
                    $scope.items=['item 1', 'item 2', 'item 3'];

                }
            })
            .state('home.paragraph',{
                template:'<p>Notice the url does not change when you come to this state</p>',
            })

            // About page showing multiple views in one page
            .state('about',{
                url:'/about',
                views: {
                    //main template
                    '': {templateUrl:'about.html'},

                    //child templates, you can also define separate controllers for each view
                    'viewOne@about': {template:'<p>Showing stuff for view one</p>'},
                    'viewTwo@about': {template:'<p>Showing stuff for view two</p>'}

                }
            });

    }).controller('HomeController', function($scope){
        //No functionality, just demonstrating that we can define controllers for states this way
    });
