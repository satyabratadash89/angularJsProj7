angular.module('myApp',[])
    .controller('httpController', function($scope, $http){
        $scope.loadFruitData= function(){
            var name = $scope.fruitName;
            if(!(name == 'banana' || name == 'apple')){
                alert('Sorry we only have bananas and apples. I\'ll give you data for banana.');
                name = 'banana';
                $scope.fruitName = name;
            }
            $http.get('fruits.json').success(function(data) {
                var id = data[$scope.fruitName];
                console.log("id: "+id);

                $http.get("color.json").success(function(data) {
                    $scope.fruitColor = data[id];
                });
                $http.get("quantity.json").success(function(data) {
                    $scope.fruitQuantity = data[id];
                });
            });
        };

    })
    .controller('deferredController', function($scope, $http, $q){

        var getFruitDataHelper = function(name){
            var deferred = $q.defer();
            var fruits  = $http.get("fruits.json"),
                color = $http.get("color.json"),
                quantity  = $http.get("quantity.json");

            $q.all([fruits, color, quantity]).then(function(result) {
                var id = result[0].data[name];
                deferred.resolve({
                    fruit_name: name,
                    fruit_color: result[1].data[id],
                    fruit_quantity: result[2].data[id]
                });
            });
            return deferred.promise;
        };



        $scope.loadFruitData= function(){
            var name = $scope.fruitName;
            if(!(name == 'banana' || name == 'apple')){
                alert('Sorry we only have bananas and apples. I\'ll give you data for banana.');
                name = 'banana';
                $scope.fruitName = name;
            }
            getFruitDataHelper(name).then(function(data){
                $scope.fruitColor = data.fruit_color;
                $scope.fruitQuantity = data.fruit_quantity;
            });

        };

    });